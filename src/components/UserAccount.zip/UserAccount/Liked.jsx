import React from 'react';
import Class from '../../assets/css/dashboard.module.css';

function Likes() {
    return (
        <div className={Class.offcanvas}>
            <div>
                lorem 30 lorem 30 lorem 30 lorem 30 lorem 30 lorem 30
            </div>
        </div>
    )
}

export default Likes;
